// import { Stack } from "expo-router";
// import { Text } from "react-native-reanimated/lib/typescript/Animated";


// export default function Index() {
//   return (
//    <Stack>
//       <Stack.Screen name= "(tab)" options={{headerShown:false}}/>
//       {/* <Text>Hello i am at index</Text> */}
//    </Stack>

//   );
// }
