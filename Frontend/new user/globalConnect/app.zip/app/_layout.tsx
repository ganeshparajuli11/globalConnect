import React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import TabLayout from './(tab)';
import AuthLayout from './(auth)/_layout';

const Stack = createNativeStackNavigator();

export default function AppLayout() {
  return (
    // Only wrap the entire navigator with NavigationContainer once
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Auth" component={AuthLayout} />
      <Stack.Screen name="Tab" component={TabLayout} />
    </Stack.Navigator>
  );
}
