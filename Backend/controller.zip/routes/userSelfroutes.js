const express = require('express');
const { checkAuthentication, checkIsUser } = require('../middleware/middleware');
const { getUserProfile, sendOTP, verifyOTP, resetPassword } = require('../controller/userSelfController');
const router = express.Router();


// Route to get user details based on the token
router.get('/getUserProfile',checkAuthentication,checkIsUser,getUserProfile);

router.post('/forgot-password', sendOTP);
router.post('/verify-otp', verifyOTP);
router.post('/reset-password', resetPassword);

module.exports = router;
