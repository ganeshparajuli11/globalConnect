const mongoose = require("mongoose");

const categorySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      unique: true, // Each category name must be unique
      required: [true, "Category name is required"], // Validation for not null
      trim: true, // Removes extra spaces
      maxlength: 50, // Limits the category name to 50 characters
    },
    created_at: {
      type: Date,
      default: Date.now, // Automatically set the creation timestamp
    },
    updated_at: {
      type: Date, // Optional field for the last edit timestamp
    },
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" }, // Automatically handle timestamps
  }
);

module.exports = mongoose.model("Category", categorySchema);
