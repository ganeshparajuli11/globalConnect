const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  age: { type: Number, required: true },
  role: { type: String, default: 'user' },
  verified: { type: Boolean, default: false },
  profile_image: { type: String, default: null },
  destination_country: { type: String, default: null },
  location: { type: String, default: null },
  is_blocked: { type: Boolean, default: false },
  reported_count: { type: Number, default: 0 },
  status: { type: String, default: 'Active' },
  date_created: { type: Date, default: Date.now },
  last_login: { type: Date, default: null },

  // Fields for following system
  followers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // Users following this user
  following: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // Users this user follows

  // Fields for Forgot Password
  reset_otp: { type: String, default: null },
  otp_expiry: { type: Date, default: null },
  otp_attempts: { type: Number, default: 0 },
  otp_blocked_until: { type: Date, default: null },
});


// Middleware to hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  console.log('Hashed Password:', this.password);
  next();
});

// Compare the provided password with the hashed password
userSchema.methods.comparePassword = async function (password) {
  return await bcrypt.compare(password, this.password);
};

// Method to check if OTP is blocked
userSchema.methods.isOTPBlocked = function () {
  if (!this.otp_blocked_until) return false;
  return this.otp_blocked_until > new Date();
};

module.exports = mongoose.model('User', userSchema);
