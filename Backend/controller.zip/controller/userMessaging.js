const isMutualFollow = async (userId1, userId2) => {
    const user1 = await User.findById(userId1);
    const user2 = await User.findById(userId2);
    return (
      user1.following.includes(userId2) &&
      user2.following.includes(userId1)
    );
  };

  
  app.post('/api/messages', async (req, res) => {
    const { senderId, receiverId, message } = req.body;
  
    if (!(await isMutualFollow(senderId, receiverId))) {
      return res.status(403).json({ error: 'Users must follow each other to send messages.' });
    }
  
    const newMessage = new Message({ sender: senderId, receiver: receiverId, message });
    await newMessage.save();
    res.status(200).json(newMessage);
  });

  