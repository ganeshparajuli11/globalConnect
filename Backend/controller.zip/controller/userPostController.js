const { Post } = require("../models/postSchema"); // Import Post and Comment models


const { comment} = require("../models/commentSchema");
const Category = require("../models/categorySchema"); // Import the Category model
const userSchema = require("../models/userSchema");

// Function to create a post
async function createPost(req, res) {
  try {
    const user_id = req.user.id; // Get the authenticated user's ID
    const {
      category_id,
      text_content,
      media_path,
      media_type,
      location,
      visibility,
    } = req.body;

    // Validate category existence
    const categoryExists = await Category.findById(category_id);
    if (!categoryExists) {
      return res.status(400).json({ message: "Invalid category ID." });
    }

    // Create and save the post
    const post = await Post.create({
      user_id,
      category_id,
      text_content,
      media_path,
      media_type,
      location,
      visibility,
    });

    res.status(201).json({
      message: "Post created successfully.",
      data: post,
    });
  } catch (error) {
    console.error("Error creating post:", error);
    res.status(500).json({
      message: "An error occurred while creating the post.",
      error: error.message,
    });
  }
}



// get all post
async function getAllPost(req, res) {
  try {
    // Fetch posts with populated fields for category and comments
    const posts = await Post.find()
      .populate("category_id", "name") // Populate category details
      .populate({
        path: "comments",
        populate: { path: "userId", select: "name profile_image" }, // Populate user details in comments
      })
      .exec();

    // Add user details for each post
    const postsWithUserDetails = await Promise.all(
      posts.map(async (post) => {

        try {
          // Ensure user_id is a valid ObjectId
          if (!post.user_id) {
            console.warn(`Post with ID ${post._id} has no user_id.`);
            return { ...post.toObject(), user: null };
          }
          console.log("checking user", post.user_id )
          const user = await userSchema.findById(post.user_id).select("name profile_image");
          
         
          if (!user) {
            console.warn(`User not found for user_id ${post.user_id}`);
          }

          return {
            ...post.toObject(), // Convert Mongoose document to plain object
            user: user || null, // Include user details or null if not found
          };
        } catch (error) {
          console.error("Error fetching user for post:", error);
          return { ...post.toObject(), user: null };
        }
      })
    );

    res.status(200).json({
      message: "Posts retrieved successfully.",
      data: postsWithUserDetails,
    });
  } catch (error) {
    console.error("Error fetching posts:", error);
    res.status(500).json({
      message: "An error occurred while fetching posts.",
      error: error.message,
    });
  }
}





module.exports = { createPost, getAllPost };
